# GHOST

- github: https://github.com/ghost-coin
- JS lib: https://github.com/ghost-coin/ghost-bitcore-lib
- explorer: https://ghostscan.io/

## Type

btc-like


## Address example

GYnnU1Bgq9x48KtSfZg7NM7pEtK3KwPovR
GVUKchWt3tm6Qa18xSRXWHCbQYrN8mN65k
GSm2BHWU8PHDs9nkQm8N97zVszrnx9BkPi
GXC2sp1ZMALy1zH26ADyvjEW5T28Axp5KN
Gdxc71kcPB3F3cD8fT2uYz6BmuJahStEBZ
GW6YpLzvEQqHwWDajqVrDqLTucwxr6hCHu


## Script support

yes