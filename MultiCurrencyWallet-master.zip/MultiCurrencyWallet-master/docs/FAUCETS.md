# Faucets

The list of faucets that we recommend to use when developing


## Testnet

BTC (testnet) - https://bitcoinfaucet.uo1.net/ (0.00093 per hour)

ETH (rinkeby) - https://testnet.help/en/ethfaucet/rinkeby
