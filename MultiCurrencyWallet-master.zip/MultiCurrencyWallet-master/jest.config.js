module.exports = {
  verbose: true,
  testURL: "https://swaponline.io",
  modulePaths: [
    "<rootDir>/src/core",
    "<rootDir>/shared",
  ]
}
