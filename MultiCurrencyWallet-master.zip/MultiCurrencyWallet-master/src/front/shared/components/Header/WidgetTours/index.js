export { WidgetWalletTour } from './WidgetWalletTour'
