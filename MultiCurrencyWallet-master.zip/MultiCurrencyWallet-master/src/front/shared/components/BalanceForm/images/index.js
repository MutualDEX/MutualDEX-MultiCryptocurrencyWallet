import swap from 'components/ui/CurrencyIcon/images/swap.svg'
import btc from 'components/ui/CurrencyIcon/images/btc.svg'
import eth from 'components/ui/CurrencyIcon/images/eth.svg'
import usdt from 'components/ui/CurrencyIcon/images/usdt.svg'


export default {
  btc,
  swap,
  eth,
  usdt,
}
