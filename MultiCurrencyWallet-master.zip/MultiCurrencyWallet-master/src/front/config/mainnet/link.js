export default {
  bitpay: 'https://www.blockchain.com/btc', //'https://insight.bitpay.com',
  blockcypher: 'https://live.blockcypher.com/',
  etherscan: 'https://etherscan.io',
  ghostscan: 'https://ghostscan.io',
  nextExplorer: 'https://explore.next.exchange',
}
