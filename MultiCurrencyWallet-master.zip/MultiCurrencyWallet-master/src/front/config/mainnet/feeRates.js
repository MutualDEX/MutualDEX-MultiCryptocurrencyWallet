export default {
  eth: 'https://www.etherchain.org/api/gasPriceOracle',
  btc: 'https://wiki.swaponline.io/blockcyper.php',
}
