export default {
  provider: 'https://mainnet.infura.io/v3/5ffc47f65c4042ce847ef66a3fa70d4c',
}
