export default [
  'BTC',
  'BTC (SMS-Protected)',
  'BTC (Multisig)',
  'ETH',
  'GHOST',
  'NEXT',
  'SWAP',
  'HDP',
  'USDT',
  'MSK',
  'RURCASH',
  'USDSWIFT',
]
