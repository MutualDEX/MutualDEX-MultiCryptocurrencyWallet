export default {
  // provider: 'https://tgeth.swaponline.site',
  provider: 'https://rinkeby.infura.io/v3/5ffc47f65c4042ce847ef66a3fa70d4c',
}
