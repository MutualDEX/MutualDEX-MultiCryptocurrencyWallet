export default {
  bitpay: 'https://www.blockchain.com/ru/btc-testnet/',//'https://test-insight.swap.online/insight',
  // bitpay: 'https://test-insight.bitpay.com',
  etherscan: 'https://rinkeby.etherscan.io',
  ghostscan: 'https://testnet.ghostscan.io',
}
