module.exports = {
  verbose: true,
  testURL: "https://swap.online",
  modulePaths: [
    "<rootDir>/node_modules/swap.core/lib",
    // "<rootDir>/node_modules/swap.core",
  ]
}
