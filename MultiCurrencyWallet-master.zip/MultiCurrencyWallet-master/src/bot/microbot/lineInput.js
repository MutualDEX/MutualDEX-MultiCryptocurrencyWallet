import readline from 'readline'

export default readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
