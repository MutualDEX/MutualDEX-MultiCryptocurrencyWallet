const SwapApp = require('./microbot')

module.exports = SwapApp
