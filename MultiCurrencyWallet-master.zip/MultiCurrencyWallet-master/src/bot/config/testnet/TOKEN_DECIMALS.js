export default {
  BTC: 8,
  ETH: 18,
  SWAP: 18,
  USDT: 6,
  default: 18,
}
