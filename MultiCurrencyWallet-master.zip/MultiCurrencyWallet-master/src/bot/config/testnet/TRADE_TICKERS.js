// constants, no other orders are allowed

export default [
  'ETH-BTC',
  'SWAP-BTC',
  'USDT-BTC',
]
