export default {
  swap: 1,
}
