export default {
  BTC: 8,
  ETH: 18,
  SWAP: 18,
  XSAT: 18,
  HDP: 4,
  BTRM: 18,
  NOXON: 0,
  USDT: 6,
  SNM: 18,
  default: 18,
}
