export default {
  'ETH':  0.0005,
  'BTC': 0.0005,
  'NOXON': 0.005,
  'USDT': 0.005,
  'SWAP':  0.0005,
  'XSAT':  0.0005,
  'HDP':  0.0005,
  'default' : 0.0005 // BTC
}
