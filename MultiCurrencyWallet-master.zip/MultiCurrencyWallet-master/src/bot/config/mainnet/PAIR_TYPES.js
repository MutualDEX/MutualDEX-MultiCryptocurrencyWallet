export default Object.freeze({
  BID: 'bid',
  ASK: 'ask',
})
