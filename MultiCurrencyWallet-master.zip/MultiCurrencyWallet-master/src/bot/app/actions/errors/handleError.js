// outputs?

export default ({ name, message, ...other }) => {
  console.error(name, message, other)
}
