start-stop-daemon --name nextd --stop
echo 'nextd stopped!'