# wget https://chain.next.exchange/download/nextcoind-3.2.0-x64_32.zip
# unzip -j nextcoind-3.2.0-x64_32.zip -p bin/nextd -d /usr/local/bin
# rm nextcoind-3.2.0-x64_32.zip
# echo 'nextd installed!'