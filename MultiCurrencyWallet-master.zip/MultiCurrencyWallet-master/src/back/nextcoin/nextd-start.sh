nextd -daemon -server -rpcuser=test -rpcpassword=test -txindex -addressindex -timestampindex -spentindex
echo 'nextd started!'