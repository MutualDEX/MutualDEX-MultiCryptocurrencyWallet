require('./test-accountFromMnemonic')
require('./test-getBalance')
