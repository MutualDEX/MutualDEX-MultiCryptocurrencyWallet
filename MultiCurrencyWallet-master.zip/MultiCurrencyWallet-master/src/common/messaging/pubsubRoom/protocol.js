'use strict'

module.exports = 'ipfs-pubsub-room/v2'
