export default {
  web3: 'web3',
  bitcoin: 'bitcoin',
  bitcoincash: 'bitcoincash',
  sumcoin: 'sumcoin',
  ghost: 'ghost',
  next: 'next',
  coininfo: 'coininfo',
  storage: 'storage',
  sessionStorage: 'sessionStorage',
  swapsExplorer: 'swapsExplorer',
  metamask: 'metamask',
  getWeb3: 'getWeb3',
}
