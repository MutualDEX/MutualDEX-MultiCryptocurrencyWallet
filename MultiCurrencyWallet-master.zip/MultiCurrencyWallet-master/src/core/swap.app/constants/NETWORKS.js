export default {
  MAINNET: 'mainnet',
  TESTNET: 'testnet',
}
