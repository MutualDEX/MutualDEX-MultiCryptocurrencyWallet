const bitcoin = require('./bitcoin')
const ethereum = require('./ethereum')

module.exports = {
  bitcoin,
  ethereum,
}
