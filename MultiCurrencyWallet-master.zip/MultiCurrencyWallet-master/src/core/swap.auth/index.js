import SwapAuth from './SwapAuth'


export default SwapAuth
