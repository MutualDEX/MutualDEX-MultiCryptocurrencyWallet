---
name: Standart Task Template
about: шаблон правильного оформления таска (за правильно оформленный таск +1 токен
  бонуса)
title: ''
labels: ''
assignees: ''

---
<!-- Please use English -->

1.  Job. What we need to do in order to implement this feature. Steps

2.  Purpose. What this feature is intended to resolve? 
a) Clients benefits

b) Our benefits

3.  Where 
a) What part of our tech resources this feature intercourse  (Back, front etc.) 

b) Where’ll we implement this feature (project, space etc.) 

4.  Estimate time of implementation this feature 

5.  Evidences.
