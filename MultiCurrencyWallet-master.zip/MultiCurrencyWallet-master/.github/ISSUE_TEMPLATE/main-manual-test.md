
**Send all coins with wallet**
- [ ] 1. ethToken
- [ ] 2. eth
- [ ] 3. btc

**Swap browser2browser**
- [ ] 1. swap - btc2eth (balance - btc: full, eth:full)
- [ ] 2. swap - btc2eth (balance - btc: 0, eth:0)

- [ ] 3. swap - btc2ethToken (balance - btc: full, eth:full)
- [ ] 4. swap - btc2ethToken (balance - btc: 0, eth:0)

**Swap browser2bot**
- [ ] 1. swap - btc2eth (balance - btc: full, eth:full)
- [ ] 2. swap - btc2eth (balance - btc: 0, eth:0)
- [ ] 3. swap - eth2btc (balance - btc: full, eth:full)
- [ ] 4. swap - eth2btc (balance - btc: 0, eth:0)

- [ ] 5. swap - btc2ethToken (balance - btc: full, eth:full)
- [ ] 6. swap - btc2ethToken (balance - btc: 0, eth:0)
- [ ] 7. swap - ethToken2btc (balance - btc: full, eth:full)
- [ ] 8. swap - ethToken2btc (balance - btc: 0, eth:0)
