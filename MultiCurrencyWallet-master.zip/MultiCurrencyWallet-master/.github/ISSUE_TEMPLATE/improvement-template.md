---
name: Improvement Template
about: Improvement Template. Every correct-formed issue gets +1 token bonus.
title: ''
labels: ''
assignees: ''

---
<!-- Please use English -->

# Problem

(What is wrong now? What is working not well?)


# Task

(What we need to do in order to implement this feature?)


# Estimate time of implementation
